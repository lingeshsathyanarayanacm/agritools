A major problem in alkaline soils is reduced nutrients. Amending soil with organic matter such as peat or sphagnum peat moss may help to lower the pH of highly alkaline soil.

**References**

- https://extension.usu.edu/yardandgarden/research/solutions-to-soil-problems-ii-high-ph
Excess sodium in soil can cause toxicity, and/or cause plant tissues to dry out. It may impair plants' ability to uptake adequate moisture. Excess sodium in soil can be easily removed by flushing the soil with fresh water, and ensuring that the water is able to be drained away.

**References**

- https://www.gardeningknowhow.com/garden-how-to/soil-fertilizers/sodium-in-plants.htm
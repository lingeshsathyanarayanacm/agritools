Liming materials contain calcium and/or magnesium in forms, which when dissolved, will neutralize soil acidity. Materials include calcitic limestone, dolomitic limestone, and hydrated lime.

**References**

- https://extension.umn.edu/liming/liming-materials-minnesota-soils
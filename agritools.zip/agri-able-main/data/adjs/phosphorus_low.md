Phosphorus deficiency can cause stunting in growth, leaves to turn purple, etc. To address phosphorus deficiency, use fertilizer high in phosphorus. As phosphorus is very immobile in soil, the fertilizer should be placed near plant roots.

**References**

- https://www.ctahr.hawaii.edu/mauisoil/c_placement.aspx
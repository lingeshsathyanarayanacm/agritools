Sodium is generally not needed in plants, and most only need a trace amount to promote metabolism.

**References**

- https://www.gardeningknowhow.com/garden-how-to/soil-fertilizers/sodium-in-plants.htm
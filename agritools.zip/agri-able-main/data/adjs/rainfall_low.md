Farmers should check moisture level of soil frequently, and hydrate soil if it is too dry. They can too change the composition of the soil by adding components that increase water retention.

**References**

- https://www.ers.usda.gov/amber-waves/2017/june/farmers-employ-strategies-to-reduce-risk-of-drought-damages/
#!/bin/bash
streamlit run Agri-able.py
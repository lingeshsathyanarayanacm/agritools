#!/bin/bash
conda install -c conda-forge --file requirements.txt